<html>  
<head>  
    <title>Registration Form</title>  
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js"></script>
</head>
<style>
 .box
 {
  width:10%;
  float: left;
 }
</style>
<body>  
    <div class="container">  
    <h2 class="text-center">Filter Data with Dropdown Select using Jquery AJAX</h2>
    <br/>
    <div class="box">
    <div class="form-group">
      <select class="form-control" onchange="selectdata(this.options[this.selectedIndex].value)">
        <option value="All">All</option>
        <option value="PhD">PhD</option>
        <option value="PDF">PDF</option>
      </select>
    </div>
    </div>
    <table class="table table-bordered table-striped">
    <thead style="background-color:#e3a53a;">
      <th>Id</th>
      <th>Name</th>
      <th>Email</th>
      <th>Category</th>
      <th>Phone</th>
      <th>Address</th>
      </thead>
    <tbody id="result">
    </tbody>
   </table>
  </div>
 </body>  
</html>
<script type="text/javascript">
$(document).ready(function(){
  showdata();
  });
function showdata()
{
  $.ajax({
      url: 'show-data.php',
      method: 'post',
      success: function(result)
      {
        $("#result").html(result);
      }
    });
}

function selectdata(cat)
{
  $.ajax({
    url: 'select-data.php',
    method: 'post',
    data: 'cat_name='+cat,
    success: function(result)
    {
      $("#result").html(result);
    }
  });
}
</script>






